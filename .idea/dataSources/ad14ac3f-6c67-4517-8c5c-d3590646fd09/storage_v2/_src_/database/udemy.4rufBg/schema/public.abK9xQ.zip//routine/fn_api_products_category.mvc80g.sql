create function fn_api_products_category(price real) returns text
    language plpgsql
as
$$
	BEGIN
		IF price > 50 THEN
			RETURN 'HIGH';
		ELSE 
			RETURN 'FUCK YOU';
		END IF;
	END;
$$;

alter function fn_api_products_category(real) owner to dylanthunn;

