create function fn_my_sum(integer, integer) returns integer
    language plpgsql
as
$$
	DECLARE
		ret integer;
	BEGIN
		ret := $1 + $2;
		
		RETURN ret;
	END;
$$;

alter function fn_my_sum(integer, integer) owner to dylanthunn;

