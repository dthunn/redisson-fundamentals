create function fn_api_orders_latest_10_orders() returns SETOF orders
    language plpgsql
as
$$
	BEGIN
		RETURN QUERY SELECT * from orders ORDER BY order_date DESC LIMIT 10;
	END;
$$;

alter function fn_api_orders_latest_10_orders() owner to dylanthunn;

