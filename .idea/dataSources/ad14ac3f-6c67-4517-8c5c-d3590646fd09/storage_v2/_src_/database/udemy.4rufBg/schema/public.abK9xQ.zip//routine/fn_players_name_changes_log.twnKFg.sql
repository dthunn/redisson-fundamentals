create function fn_players_name_changes_log() returns trigger
    language plpgsql
as
$$
	BEGIN
			INSERT INTO players_audits (player_id, name, edit_date)
			VALUES (NEW.player_id, NEW.name, NOW());
		RETURN NEW;
	END;
$$;

alter function fn_players_name_changes_log() owner to dylanthunn;

