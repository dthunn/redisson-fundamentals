create function fn_my_check_value(x integer DEFAULT 0) returns text
    language plpgsql
as
$$
	BEGIN
		CASE x
			WHEN 10 THEN
				RETURN 'VALUE = 10';
			ELSE
				RETURN 'Not 10';
		END CASE;
	END;
$$;

alter function fn_my_check_value(integer) owner to dylanthunn;

