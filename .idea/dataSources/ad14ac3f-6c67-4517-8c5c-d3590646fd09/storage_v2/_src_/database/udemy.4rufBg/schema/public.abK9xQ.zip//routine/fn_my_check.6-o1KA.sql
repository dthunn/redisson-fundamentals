create function fn_my_check(x integer DEFAULT 0, y integer DEFAULT 0) returns text
    language plpgsql
as
$$
	BEGIN
		IF x > y THEN
			RETURN 'x > y';
		ELSE
			RETURN 'fuck you';
		END IF;
	END;
$$;

alter function fn_my_check(integer, integer) owner to dylanthunn;

