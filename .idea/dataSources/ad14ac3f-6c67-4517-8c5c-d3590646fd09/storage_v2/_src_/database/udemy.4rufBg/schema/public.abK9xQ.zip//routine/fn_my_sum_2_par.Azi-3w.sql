create function fn_my_sum_2_par(x integer, y integer, OUT z integer) returns integer
    language plpgsql
as
$$
	BEGIN 
		z := x + y;
	END;
$$;

alter function fn_my_sum_2_par(integer, integer, out integer) owner to dylanthunn;

