create function fn_api_products_max_price() returns bigint
    language plpgsql
as
$$
	BEGIN
		RETURN MAX(unit_price)
		FROM products;
	END;
$$;

alter function fn_api_products_max_price() owner to dylanthunn;

